﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstracta;
using System.Xml.Serialization;

namespace ClasesInstanciables
{
    public sealed class Profesor:Universitario
    {
        #region Atributos
        private Queue<Universidad.EClases> clasesDelDia;
        private static Random random;
        #endregion
        #region Metodos
        /// <summary>
        /// Sobreescribe metodo heredado de la clase base.
        /// </summary>
        /// <returns></returns>
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(this.ParticiparEnClase());
            return sb.ToString();
        }
        /// <summary>
        ///Implementa metodo abstracto de la clase base. 
        /// </summary>
        /// <returns></returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CLASES DEL DIA:  ");
            foreach (Universidad.EClases a in this.clasesDelDia)
            {
                sb.AppendLine(a.ToString());
            }
            return sb.ToString();
        }
        /// <summary>
        /// Da dos clases de forma aleatorio al profesor.De ser la misma le volvera asignar una hasta romper la condicion.
        /// </summary>
        private void _randomClases()
        {
            this.clasesDelDia.Enqueue((Universidad.EClases)Profesor.random.Next(0, 4));
            this.clasesDelDia.Enqueue((Universidad.EClases)Profesor.random.Next(0, 4));
            Universidad.EClases aux = this.clasesDelDia.ElementAt(0);
            Universidad.EClases aux1 = this.clasesDelDia.ElementAt(1);

            while (aux == aux1)
            {
                this.clasesDelDia.Enqueue((Universidad.EClases)Profesor.random.Next(0, 4));
                aux = this.clasesDelDia.ElementAt(0);
                aux1 = this.clasesDelDia.ElementAt(1);
            }

        }
        #endregion
        #region Sobrecargas
        public static bool operator==(Profesor i,Universidad.EClases clase)
        {
            bool ok = false;
            foreach(Universidad.EClases a in i.clasesDelDia)
            {
                if(a==clase)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        }
        public static bool operator!=(Profesor i,Universidad.EClases clase)
        { return !(i == clase); }
        /// <summary>
        /// Hace publicos los datos del profesor.
        /// </summary>
        /// <returns></returns>
        public string ToString()
        {
            return this.MostrarDatos();
        }
        #endregion
        #region Constructores
        public Profesor() { }
        static Profesor()
        {
            random = new Random();
        }
        public Profesor(int id,string nombre,string apellido,string dni,ENacionalidad nacionalidad)
            :base(id,nombre,apellido,dni,nacionalidad)
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases();
        }
        #endregion
        
      

    }
}
