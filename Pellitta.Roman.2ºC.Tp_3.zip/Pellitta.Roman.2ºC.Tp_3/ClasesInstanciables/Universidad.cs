﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
    
    public class Universidad
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }
        private List<Alumno> alumnos;
        private List<Jornada> jornadas;
        private List<Profesor> profesores;
        public List<Alumno>Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {
                this.alumnos = value;
            }
        }
        public List<Jornada>Jornadas
        {
            get
            {
                return this.jornadas;
            }
            set
            {
                this.jornadas=value;
            }
        }
        public List<Profesor>Profesores
        {
            get
            {
                return this.profesores;
            }
            set
            {
                this.profesores = value;
            }
        }
        public Jornada this[int i]
        {
            get
            {
                return this.jornadas.ElementAt(i);
            }
            set
            {
                this.jornadas[i]=value;
            }
        }
   
        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.profesores = new List<Profesor>();
            this.Jornadas = new List<Jornada>();
        }
        public static bool operator ==(Universidad u,Alumno a)
        {
            bool ok = false;
            foreach(Alumno b in u.Alumnos)
            {
                if(b==a)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        }
        public static bool operator !=(Universidad u, Alumno a)
        {
            return !(u == a);
        }
        public static bool operator ==(Universidad u,Profesor p)
        {
            bool ok = false;
           
                if(u.Profesores.Contains(p))
                {
                    ok = true;
                }
            
            return ok;
        }
        public static bool operator !=(Universidad u,Profesor p)
        {
            return !(u == p);
        }
        public static Profesor operator ==(Universidad u,EClases clases)
        {
           
            foreach(Profesor a in u.Profesores)
            {
                if(a==clases)
                {
                     return a;
                }
            }
            throw new SinProfesorException();
        }
        public static Profesor operator !=(Universidad u, EClases clases)
        {
            foreach (Profesor a in u.Profesores)
            {
                if (a != clases)
                {
                    return a;
                }
            }
            throw new SinProfesorException();
        }
        public static Universidad operator +(Universidad u,Alumno a)
        {
            if(u!=a)
            {
                u.Alumnos.Add(a);
            }
            else
            {
                throw new AlumnoRepetidoException();
            }
            return u;
        }
        public static Universidad operator +(Universidad u,Profesor p)
        {
            if(u!=p)
            {
                u.Profesores.Add(p);
                return u;
            }
            else
            {
                throw new SinProfesorException();
            }
            
        }
        public static Universidad operator +(Universidad u,EClases clases)
        {
            
           
            Jornada j = new Jornada(clases,u==clases );
            foreach(Alumno a in u.Alumnos)
            {
                if(a==clases)
                {
                    j.Alumnos.Add(a);
                }
            }
            u.jornadas.Add(j);               
            
            return u;
        }
        public static void Guardar(Universidad uni)
        {
            Xml<Universidad> aux = new Xml<Universidad>();
            if (aux.Guardar("Universidad.xml", uni) == false)
            { 
                throw new ArchivosException();
            }
        }
        public Universidad Leer()
        {
            Universidad retorno;
            Xml<Universidad> aux = new Xml<Universidad>();
            if (aux.Leer("Universidad.xml", out retorno) == false)
            { 
                throw new ArchivosException();
            }
            return retorno;
        }
        private  string MostrarDatos(Universidad uni)
        {
            StringBuilder sb = new StringBuilder();

            foreach (Jornada j in uni.Jornadas)
            {
                sb.AppendLine("JORNADA:");
                sb.AppendLine(j.ToString());
                sb.AppendLine("< ---------------------- >");
            }

            return sb.ToString();
        }

  
        public string ToString()
        {
            return this.MostrarDatos(this);
        }

    }
}
