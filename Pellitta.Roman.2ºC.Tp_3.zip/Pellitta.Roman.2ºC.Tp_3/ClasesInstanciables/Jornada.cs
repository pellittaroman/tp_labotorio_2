﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;



namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clases;
        private Profesor instructor;

        public List<Alumno>Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {
                this.alumnos = value;
            }
        }
        public Universidad.EClases Clases
        {
            get
            {
                return this.clases;
            }
            set
            {
                this.clases = value;
            }
        }
        public Profesor Instructor
        {
            get
            {
                return this.instructor;
            }
            set
            {
                this.instructor = value;
            }
        }
        
        private Jornada()
        {
            alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clase, Profesor instructor)
            :this()
        {
            this.Clases = clase;
            this.Instructor = instructor;
        }
        public static bool operator ==(Jornada j,Alumno a)
        {
            bool ok = false;
            foreach(Alumno b in j.alumnos)
            {
                if(b==a)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        }
        public static bool operator!=(Jornada j,Alumno a)
        {
            return !(j == a);
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
            if(j!=a)
            {
                j.alumnos.Add(a);
            }
            return j;
        }
        public string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("CLASE DE {0} POR {1}\n",this.Clases,this.Instructor.ToString());
            sb.AppendLine("ALUMNOS:");
            foreach (Alumno a in this.Alumnos)
            {
                sb.AppendLine(a.ToString());
            }

            return sb.ToString();
        }
        public static void Guardar(Jornada jornada)
        {
            Texto aux = new Texto();
            if (aux.Guardar("Jornada.txt", jornada.ToString()) == false)
            {  
                throw new ArchivosException();
            }
        }
        public static string Leer()
        {
            Texto aux = new Texto();
            string datos;
            if (aux.Leer("Jornada.txt", out datos) == false)
            { 
                throw new ArchivosException();
            }

            return datos;
        }

    }
}
