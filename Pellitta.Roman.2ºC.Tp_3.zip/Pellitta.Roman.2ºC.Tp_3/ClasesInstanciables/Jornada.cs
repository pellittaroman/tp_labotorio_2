﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;



namespace ClasesInstanciables
{
    public class Jornada
    {
        #region Atributos
        private List<Alumno> alumnos;
        private Universidad.EClases clases;
        private Profesor instructor;
        #endregion
        #region Propiedades
        public List<Alumno>Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {
                this.alumnos = value;
            }
        }
        public Universidad.EClases Clases
        {
            get
            {
                return this.clases;
            }
            set
            {
                this.clases = value;
            }
        }
        public Profesor Instructor
        {
            get
            {
                return this.instructor;
            }
            set
            {
                this.instructor = value;
            }
        }
        #endregion
        #region Constructores
        private Jornada()
        {
            alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clase, Profesor instructor)
            :this()
        {
            this.Clases = clase;
            this.Instructor = instructor;
        }
        #endregion
        #region Sobrecargas
        public static bool operator ==(Jornada j,Alumno a)
        {
            bool ok = false;
            foreach(Alumno b in j.alumnos)
            {
                if(b==a)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        }
        public static bool operator!=(Jornada j,Alumno a)
        {
            return !(j == a);
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
            if(j!=a)
            {
                j.alumnos.Add(a);
            }
            return j;
        }
        /// <summary>
        /// Muestra los datos correspondientes a la jornada.
        /// </summary>
        /// <returns></returns>
        public string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("CLASE DE {0} POR {1}\n",this.Clases,this.Instructor.ToString());
            sb.AppendLine("ALUMNOS:");
            foreach (Alumno a in this.Alumnos)
            {
                sb.AppendLine(a.ToString());
            }

            return sb.ToString();
        }
        #endregion
        #region Metodos
        /// <summary>
        /// Guardar la jornada una archivo de texto.De no poder lanza una Excepcion del tipo ArchivoException.
        /// </summary>
        /// <param name="jornada"></param>
        public static void Guardar(Jornada jornada)
        {
            Texto aux = new Texto();
            if (aux.Guardar("Jornada.txt", jornada.ToString()) == false)
            {  
                throw new ArchivosException();
            }
        }
        /// <summary>
        /// Lee una jornada desde un archivo de texto. De no poder lanzxa una excepcion del tipo ArchivosException
        /// </summary>
        /// <returns></returns>
        public static string Leer()
        {
            Texto aux = new Texto();
            string datos;
            if (aux.Leer("Jornada.txt", out datos) == false)
            { 
                throw new ArchivosException();
            }

            return datos;
        }
        #endregion
    }
}
