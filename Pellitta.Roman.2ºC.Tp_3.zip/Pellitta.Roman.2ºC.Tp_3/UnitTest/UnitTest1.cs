﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesAbstracta;
using ClasesInstanciables;
using Excepciones;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Universidad uni = new Universidad();
            try
            {
                uni += Universidad.EClases.SPD;
            }
            catch (Exception a)
            {

                Assert.IsInstanceOfType(a, typeof(SinProfesorException));
            }

        }
        [TestMethod]
        public void Test2()
        {
            Alumno a = new Alumno(1, "Fede", "Davila", "31333444", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            Assert.IsTrue(31333444 == a.DNI);
        }
        [TestMethod]
        public void Test3()
        {
            try
            {
                Alumno a = new Alumno(1, "Fede", "Davila", "31aaa444", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            }
            catch (Exception a)
            {
                Assert.IsInstanceOfType(a, typeof(DniInvalidoException));
            }
           
            
        }
        [TestMethod]
        public void Test4()
        {
            Universidad uni = new Universidad();
            Alumno a1 = new Alumno(1, "Juan", "Lopez", "12234456",
          ClasesAbstracta.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
          Alumno.EEstadoCuenta.Becado);
            uni += a1;
            uni += Universidad.EClases.Programacion;
            Assert.IsNotNull(uni.Jornadas);
            Assert.IsNotNull(uni.Alumnos);
            Assert.IsNotNull(uni.Profesores);
        }
    }
}
