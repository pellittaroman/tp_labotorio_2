﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstracta
{
    public abstract class Universitario:Persona
    {
        private int legajo;
        public bool Equals(object obj)
        {
            bool ok = false;
            if (obj!=null&&obj is Universitario)
            {
                Universitario aux = (Universitario)obj;
                if(aux.legajo==this.legajo&&aux.DNI==this.DNI)
                {
                    ok = true;
                }
            }
            return ok;
        }
        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendFormat("LEGAJO: {0}", this.legajo);
            return sb.ToString();
        }
        protected abstract string ParticiparEnClase();
        public Universitario() { }
        public Universitario(int id,string nombre, string apellido,string dni,ENacionalidad nacionalidad)
            :base(nombre,apellido,dni,nacionalidad)
        {
            this.legajo = id;
        }
        public static bool operator==(Universitario pg1,Universitario pg2)
        {

            return pg1.Equals(pg2);
           
           
        }
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }
    }
}
