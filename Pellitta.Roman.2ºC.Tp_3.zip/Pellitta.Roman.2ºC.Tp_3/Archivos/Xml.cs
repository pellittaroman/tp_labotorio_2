﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;

namespace Archivos
{
    public class Xml<T>:IArchivo<T>
    {
        public bool Guardar(string archivo, T datos)
        {
            XmlSerializer ser = new XmlSerializer(typeof(T));
            XmlTextWriter writer = null;
            bool retorno = true; //Devuelve true si no se produjeron excepciones.
            try
            {
                writer = new XmlTextWriter(archivo, null);
                ser.Serialize(writer, datos);
            }
            catch (Exception)
            {
                retorno = false; //Devuelve false si se produjeron excepciones. 
            }
            finally
            {
                writer.Close();
            }
            return retorno;
        }
        public bool Leer(string archivo, out T datos)
        {
            XmlSerializer file = new XmlSerializer(typeof(T));
            XmlTextReader reader = null;
            bool retorno = true;          

            try
            {
                reader = new XmlTextReader(archivo);
                datos = (T)file.Deserialize(reader);
            }
            catch (Exception)
            {
                datos = default(T); 
                retorno = false; 
            }
            finally
            {
                reader.Close();
            }
            return retorno;
        }
    }
}
