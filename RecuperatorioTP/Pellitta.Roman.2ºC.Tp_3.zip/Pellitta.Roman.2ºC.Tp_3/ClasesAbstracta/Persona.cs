using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Excepciones;

namespace ClasesAbstracta
{
    public abstract class Persona
    {
        #region Enumerados
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        #endregion
        #region Atributos
        private string nombre;
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        #endregion
        #region Propiedades
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = ValidarNombreApellido(value);
            }
        }
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                this.apellido = ValidarNombreApellido(value);
            }
        }
        public int DNI
        {
            get
            {
                return this.dni;
            }
            set
            {
                this.dni = ValidarDNI(this.Nacionalidad,value);
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                this.nacionalidad = value;
            }
        }
        public string StringToDni
        {
            set
            {
                this.dni = ValidarDNI(this.Nacionalidad,value);
            }
        }
        #endregion
        #region Constructores
        public Persona()
        {

        }
        public Persona(string nombre,string apellido,ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }
        public Persona(string nombre,string apellido,int dni,ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this.DNI = dni;
        }
        public Persona(string nombre, string apellido,string dni,ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this.StringToDni = dni;
        }
        #endregion
        #region Sobrecargas
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("NOMBRE: {0} {1}\n", this.Apellido, this.Nombre);
            sb.AppendFormat("NACIONALIDAD: {0}", this.Nacionalidad);
            return sb.ToString();
        }
        #endregion
        #region Metodos
        /// <summary>
        /// Comprueba que el nombre y apellido tenga carateres validos.
        /// </summary>
        /// <param name="dato"></param>
        /// <returns></returns>
        private string ValidarNombreApellido(string dato)
        {
            if (!Regex.IsMatch(dato, @"^([a-zA-Záéíóú]+)(\s[a-zA-Záéíóú]+)*$"))
            {
                dato = "";
            }
            return dato;
        }
        /// <summary>
        /// comprueba que el numero de dni sea valido.
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>del tipo string.
        /// <returns></returns>el dni en un int o lanza una excepcion del tipo DniInvalidoException.
        private int ValidarDNI(ENacionalidad nacionalidad,string dato)
         {
             int retorno;
             if(int.TryParse(dato,out retorno))
             {
                 if(retorno>0&&retorno<100000000)
                 {
                     switch(nacionalidad)
                     {
                         case ENacionalidad.Argentino:
                             if(retorno>89999999)
                                 {
                                     throw new NacionalidadInvalidaException("La nacionalidad no coincide con el numero de DNI");
                                 }
                             break;
                         case ENacionalidad.Extranjero:
                             if(retorno<90000000)
                                 {
                                     throw new NacionalidadInvalidaException("La nacionalidad no coincide con el numero de DNI");
                                 }
                             break;
                     }
                 }
                 else
                 {
                     throw new DniInvalidoException("Numero de DNI invalido");
                 }



             }
             else
             {
                 throw new DniInvalidoException("NUmero de DNI invalido");
             }
             return retorno;
         }
        /// <summary>
        /// Valida que el dni sea valido.
         /// </summary>
         /// <param name="nacionalidad"></param>
         /// <param name="dato"></param>de tipo int.
         /// <returns></returns>el numero de dni validado o lanza una excepcion del tipo DniInvalidoException.
         private int ValidarDNI(ENacionalidad nacionalidad,int dato)
         {
             return ValidarDNI(nacionalidad, dato.ToString());
         }
        #endregion

    }
}
