using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstracta
{
    public abstract class Universitario:Persona
    {
        #region Atributos
        private int legajo;
        #endregion
        #region Sobrecargas
        public override bool Equals(object obj)
        {
            bool ok = false;
            if (obj!=null&&obj is Universitario)
            {
                Universitario aux = (Universitario)obj;
                if(aux.legajo==this.legajo&&aux.DNI==this.DNI)
                {
                    ok = true;
                }
            }
            return ok;
        }
        public static bool operator ==(Universitario pg1, Universitario pg2)
        {

            return pg1.Equals(pg2);


        }
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }
        #endregion
        #region Metodos
        /// <summary>
        /// muestra los datos del universitario.
        /// </summary>Permite ser sobreescrito por las clases derivadas.
        /// <returns></returns>
        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendFormat("LEGAJO: {0}", this.legajo);
            return sb.ToString();
        }
        /// <summary>
        /// Metodo abstracto solo firma.
        /// </summary>
        /// <returns></returns>
        protected abstract string ParticiparEnClase();
        #endregion
        #region Constructores
        public Universitario()
        {

        }
        public Universitario(int id,string nombre, string apellido,string dni,ENacionalidad nacionalidad)
            :base(nombre,apellido,dni,nacionalidad)
        {
            this.legajo = id;
        }
        #endregion
    }
}
