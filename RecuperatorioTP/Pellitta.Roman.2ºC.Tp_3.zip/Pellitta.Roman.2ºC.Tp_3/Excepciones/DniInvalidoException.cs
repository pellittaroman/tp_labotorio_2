using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException:Exception
    {
        #region Atributos
        private string mensajeBase;
        #endregion
        #region Constructores
        public DniInvalidoException()
        {

        }
        public DniInvalidoException(string mensaje):base(mensaje,null)
        {
            this.mensajeBase = mensaje;
        }
        public DniInvalidoException(Exception e) : base("", e) { }
        public DniInvalidoException(string mensaje,Exception innerException)
            :base(mensaje,innerException)
        {

        }
        #endregion
    }
}
