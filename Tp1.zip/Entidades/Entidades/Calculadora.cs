﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        /// <summary>
        /// Realiza la operacion matetatica requerida.
        /// </summary>
        /// <param name="num1"></param>numero 1.
        /// <param name="num2"></param>numero 2, recuerde en caso de la division tira error de ser '0'.
        /// <param name="operador"></param>El string incando la operacion desea. Si pasa alguno que no corresponde devuelve '+'.
        /// <returns></returns>
        public static double Operar(Numero num1, Numero num2, string operador)
        {
            
            double ret=0;
            operador=ValidarOperador(operador);
            switch (operador)
            {
                
                case "-":
                    ret = num1 - num2;
                    break;
                case "/":
                    ret = num1 / num2;
                    break;
                case "*":
                    ret = num1 * num2;
                    break;
                default:
                    ret = num1 + num2;
                    break;
            }
            return ret;
        }
        private static string ValidarOperador(string operador)
        {
           string retorno = "+";
           if(operador=="-"|| operador=="*"||operador=="/")
            {
                retorno = operador;
            }
            return retorno;
        }
    }
    
}
