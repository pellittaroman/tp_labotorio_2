﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        private double numero;
        private double ValidarNumero(string strNumero)
        {
            double retorno;
            double.TryParse(strNumero, out retorno);
            return retorno;
        }
        /// <summary>
        /// inicializa el numero en 0.
        /// </summary>
        public Numero()
        {
           
        }
        /// <summary>
        /// Inicializa el numero con el numero pasado por parametro.
        /// </summary>
        /// <param name="numero"></param>
        public Numero(double numero)
        {
            this.numero = numero;
        }
        /// <summary>
        /// Inicializa el numero con el numero pasado por parametro, previo validarlo.
        /// </summary>
        /// <param name="strNumero"></param>
        public Numero(string strNumero)
        {
            setNumero = strNumero;
        }
        private string setNumero
        {
            set
            {
                this.numero = ValidarNumero(value);
            }
        }
        /// <summary>
        /// Convierte el numero decimal en binario y lo devuelve en formato de string.
        /// </summary>devuelve "no". si hay algun error.
        /// <param name="numero"></param>El numero que desea convertir.
        /// <returns></returns>
        public static string DecimalBinario(double numero)
        {
            string cadena = "";
            numero = (int)numero;
            if (numero > 0)
            {

                while (numero >= 2)
                {
                    if (numero % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    numero = (int)(numero / 2);
                }
                if (numero == 1)
                {
                    cadena = "1" + cadena;
                }
                else
                {
                    cadena = "0" + cadena;
                }
            }
            else
            {
                cadena = "E";
            }

            return cadena;
        }
        /// <summary>
        /// Convierte un binario en decimal. Devuelve un string.
        /// </summary>devuelve "no". si hay algun error.
        /// <param name="binario"></param>El numero que desea convertir pasado en formato de string.
        /// <returns></returns>
        public static string BinarioDecimal(string binario)
        {
            string retorno;
            int ok=1;
            for (int i = 0; i < binario.Length; i++)
            {
                if (int.Parse(binario.Substring(i, 1)) != 1 && double.Parse(binario.Substring(i, 1)) != 0)
                {
                    ok = 0;
                }
            }

            double exponente = binario.Length - 1;
            double num_decimal = 0;

            if (ok != 0)
            {
                for (int i = 0; i < binario.Length; i++)
                {
                    if (double.Parse(binario.Substring(i, 1)) == 1)
                    {
                        num_decimal = num_decimal + double.Parse(System.Math.Pow(2, exponente).ToString());
                    }
                    exponente--;
                }
                retorno = "" + num_decimal;
            }
            else
            {
                retorno = "E";
            }

            


            return retorno;


        }

        /// <summary>
        /// Convierte el numero decimal en binario y lo devuelve en formato de string.
        /// </summary>devuelve "no". si hay algun error.
        /// <param name="numero"></param>El numero que desea convertir pasado en formato de string.
        /// <returns></returns>
        public static string DecimalBinario(string strNumero)
        {
            double ok;
            string retorno = "0";
            double.TryParse(strNumero, out ok);
            if(ok!=0)
            {
                retorno = DecimalBinario(ok);
            }
            return retorno;
        }
        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }
        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }
        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }
        public static double operator /(Numero n1, Numero n2)
        {
            return n1.numero / n2.numero;
        }
    }
}
