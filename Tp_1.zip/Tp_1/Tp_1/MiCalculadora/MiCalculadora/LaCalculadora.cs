﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class LaCalculadora : Form
    {
        public LaCalculadora()
        {
            InitializeComponent();
        }

        private void Cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar();

        }
        private void Limpiar()
        {
            Numero1.Text = "";
            Numero2.Text = "";
            Resultado.Text = "";
            Operador.Text = "";
        }
        private static double Operar(string numero1, string numero2, string operador)
        {
            double retorno;
            

            retorno =Calculadora.Operar(new Numero(numero1),new Numero(numero2),operador );

            return retorno;
        }
        private  void Operar_Click(object sender, EventArgs e)
        {

            double mostrar;
            mostrar= Operar(Numero1.Text, Numero2.Text, Operador.Text);
            Resultado.Text = "" + mostrar;

        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {

            Resultado.Text = Numero.DecimalBinario(Resultado.Text);
           
            
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            Resultado.Text = Numero.BinarioDecimal(Resultado.Text);
        }

        private void Operador_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void LaCalculadora_Load(object sender, EventArgs e)
        {
            Operador.SelectedIndex = 0;
        }
    }
}
