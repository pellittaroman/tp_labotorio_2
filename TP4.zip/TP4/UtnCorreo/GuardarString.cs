﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace UtnCorreo
{
    public static class GuardarString
    {
        /// <summary>
        /// Metodo de extencion para el tipo string. Por cual guarda dicho string en un archivo de texto. 
        /// </summary>
        /// <param name="texto"></param>
        /// <param name="archivo"></param>
        /// <returns></returns>
       public static bool Guardar(this string texto,string archivo)
        {
            bool ok = true;
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + archivo,true );
                writer.Write(texto);
            }
            catch (Exception a)
            {

                ok = false;
            }
            finally
            {
                writer.Close();
            }
            
            
            

            
            return ok;
        }
    }
}
