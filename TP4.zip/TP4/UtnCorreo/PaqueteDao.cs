﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace UtnCorreo
{
     public static class PaqueteDao
    {
        #region Atributos
        private static SqlCommand command;
        private static SqlConnection connection;
        #endregion
        #region Constructor
        static PaqueteDao()
        {
            connection = new SqlConnection("Data Source =.\\SQLEXPRESS; Initial Catalog = correo-sp-2017; Integrated Security = True");
            command = new SqlCommand();
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
        }
        #endregion
        #region Metodos
        /// <summary>
        /// Inserta en base de datos cada paquete que se genera. 
        /// Si produce algun error lo lanza sera captura por mockDeVida, 
        /// que se relanza al operador sobrecargado + de Correo y relanza al btn_Agregar el cual lo mostrara en MessageBox. 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool Insertar(Paquete p)
        {
            bool ok = false;
            try
            {
                command.CommandText = "INSERT INTO Paquetes (direccionEntrega, trackingID, alumno) VALUES ('" + p.DireccionEntrega + "', '" + p.TrackingID + "', 'Roman Pellitta')";
                connection.Open();
                command.ExecuteNonQuery();
                ok = true;
                
            }
            catch(Exception a)
            {
                throw a;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                    connection.Close();
            }
            return ok;
        }
        #endregion
    }
}
