﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace UtnCorreo
{
    public class Correo:IMostrar<List<Paquete>>
    {
        #region Atributos
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;
        #endregion
        #region Propiedades
        public List<Paquete> Paquetes
        {
            get
            {
                return this.paquetes;
            }
            set
            {
                this.paquetes= value;
            }
        }
        #endregion
        #region Constructor
        public Correo()
        {
            paquetes = new List<Paquete>();
            mockPaquetes = new List<Thread>();
        }
        #endregion
        #region Metodos
        /// <summary>
        /// Se encarga de ver si quedan hilos activos y cerrarlos.
        /// </summary>
        public void FinEntrengas()
        {
            foreach(Thread t in this.mockPaquetes)
            {
                if(t.IsAlive)
                {
                    t.Abort();
                }
            }

        }
        /// <summary>
        /// Muestra los datos de toda las lista de elementos.
        /// </summary>
        /// <param name="elemento"></param>
        /// <returns></returns>
        public string MostrarDatos(IMostrar<List<Paquete>> elemento)
        {
            StringBuilder sb = new StringBuilder();
            if (elemento is Correo)
            {
               foreach (Paquete p in ((Correo)elemento).paquetes)
                {
                    sb.AppendLine(string.Format("{0} para {1} ({2})", p.TrackingID, p.DireccionEntrega, p.Estado));
                }
            }
            
            return sb.ToString();
        }
        #endregion
        #region Sobrecarga
        /// <summary>
        /// Se encarga de agregar un paquete a lista si este no esta repetido, de ser asi lanza una Excepcion.
        /// Abre un nuevo hilo, lo agrega a la lista de hilos y lo inica
        /// </summary>
        /// <param name="c"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        public static Correo operator +(Correo c, Paquete p)
        {
            foreach(Paquete aux in c.Paquetes)
            {
                if(aux==p)
                {
                    throw new TrackingIdRepetidoException("Tracking ID repetido");
                }
            }
            c.Paquetes.Add(p);
            try
            {
                Thread t = new Thread(p.MockCicloDeVida);
                c.mockPaquetes.Add(t);
                t.Start();
            }
            catch ( Exception a)
            {

                throw a;
            }
            
            return c;
        }
        #endregion
    }
}
