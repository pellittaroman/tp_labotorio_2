﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace UtnCorreo
{
    public class Paquete : IMostrar<Paquete>
    {
        #region Enumerado
        public enum EEstado
        {
            Ingresado,
            EnViaje,
            Entregado
        }
        #endregion
        #region Delegado Evento
        public delegate void DelegadoEstado(object sender, EventArgs e);
        public event DelegadoEstado InformarEstado;
        #endregion
        #region Atributos
        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;
        #endregion
        #region Propiedades
        public Paquete(string direccionEntrega,string trackingId)
        {
            this.TrackingID = trackingId;
            this.DireccionEntrega = direccionEntrega;
            this.Estado = EEstado.Ingresado;
            
        }
     
        public string DireccionEntrega
        {
            get
            {
                return this.direccionEntrega;
            }
            set
            {
                this.direccionEntrega = value;
            }
        }
        public EEstado Estado
        {
            get
            {
                return this.estado;
            }
            set
            {
                this.estado = value;
            }
        }
        public string TrackingID
        {
            get
            {
                return this.trackingID;
            }
            set
            {
                this.trackingID = value;
            }

        }
        #endregion
        #region Metodos
        /// <summary>
        /// Metodo por el cual se cambia cada 4 seg. el estado a llegar a "Entregado".
        /// Informa el cambio a travez del evento. 
        /// Por ultimo carga el paquete en la base de datos.
        /// </summary>
        public void MockCicloDeVida()
        {

            while (Estado != EEstado.Entregado)
            {
                InformarEstado.Invoke(this, null);
                switch (Estado)
                {
                    case EEstado.Ingresado:
                        Thread.Sleep(4000);
                        Estado = EEstado.EnViaje;
                        InformarEstado.Invoke(this, null);
                        break;
                    case EEstado.EnViaje:
                        Thread.Sleep(4000);
                        Estado = EEstado.Entregado;
                        InformarEstado.Invoke(this, null);
                        break;
                }
                
            }

            try
            {
                PaqueteDao.Insertar(this);
            }
            catch (Exception a)
            {

                throw a;
            }

        }
        /// <summary>
        /// Muestra el paquete con el formato pedido.
        /// </summary>
        /// <param name="elemento"></param>
        /// <returns></returns>
        public string MostrarDatos(IMostrar<Paquete> elemento)
        {
            Paquete e = (Paquete)elemento;
            return string.Format("{0} para {1}", e.TrackingID, e.DireccionEntrega);
        }
        #endregion
        #region Sobrecargas
        public override string ToString()
        {
            return this.MostrarDatos(this);
        }
        public static bool operator ==(Paquete p1, Paquete p2)
        {
            return p1.TrackingID == p2.TrackingID;
        }
        public static bool operator !=(Paquete p1, Paquete p2)
        {
            return !(p1 == p2);
        }
        #endregion
    }
}
