﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UtnCorreo;


namespace CorreoForm
{
    public partial class Formulario : Form
    {
        private Correo correo;
        private Paquete p1=null;
        public Formulario()
        {
            InitializeComponent();
            correo = new Correo();
        }
        /// <summary>
        /// Metodo que se encarga de limpiar las tres listbox, y ir agregando el paquete en la lista que corresponda segun su estado.
        /// </summary>
        private void ActualizarEstados()
        {
            if (!(lstEstadoEntregado.InvokeRequired && lstEstadoEnViaje.InvokeRequired && lstEstadoIngresado.InvokeRequired))
            {
                lstEstadoEntregado.Items.Clear();
                lstEstadoEnViaje.Items.Clear();
                lstEstadoIngresado.Items.Clear();

                foreach (Paquete p in correo.Paquetes)
                {
                    switch (p.Estado)
                    {
                        case Paquete.EEstado.Ingresado:
                            lstEstadoIngresado.Items.Add(p);
                            break;
                        case Paquete.EEstado.EnViaje:
                            lstEstadoEnViaje.Items.Add(p);
                            break;
                        case Paquete.EEstado.Entregado:
                            lstEstadoEntregado.Items.Add(p);
                            break;

                    }
                }
            }
            else
            {
                Paquete.DelegadoEstado recall = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(recall, new object[] { });
            }
        }
        /// <summary>
        /// Llama al metodo fin de entregas encargado de cerrar los hilos.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Formulario_FormClosing(object sender, FormClosingEventArgs e)
        {
            correo.FinEntrengas();
        }

        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);        }
        /// <summary>
        /// Es el metodo que se ejecutara cuando el se haga click en el boton "Mostrar Todos". 
        /// El mismo mostrara todos los paquetes en el richtextBox.
        /// Por ultimo guardara toda la informacion en el archivo "salida.txt" en el Escritorio del equipo.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="elemento"></param>
        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            
            if(elemento!=null)
            {
                richTextBox1.Text = elemento.MostrarDatos(elemento);
                try
                {
                    elemento.MostrarDatos(elemento).Guardar("salida.txt");
                }
                catch (Exception a)
                {

                    MessageBox.Show(a.Message);
                }
            }
        }
        /// <summary>
        /// Agrega un paquete a la lista de paquetes del correo, asocia el evento con el manejador.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            p1 = new Paquete(textBox1.Text, mtxtTrackingID.Text);
            p1.InformarEstado += paq_InformaEstado;
            
            try
            {
                correo += p1;
            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);
            }

        }
        /// <summary>
        /// El manejador ve si require ser invocado, sino ejecuta el metodo Actualizar estado.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e });
            }
            else
            {
                ActualizarEstados();
            }
        }
       private void cmsListas_Opening(object sender, CancelEventArgs e)
        {

        }
        /// <summary>
        /// Es el la accion que se ejecutara en el menu en el "Mostrar".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
        }
    }
}
