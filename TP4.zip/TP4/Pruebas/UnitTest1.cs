﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtnCorreo;

namespace Pruebas
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// Prueba si se lanza la Excepcion TrackingIDRepetidoException.
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
            //Arrange
            Correo c1;
            Paquete p1;
            Paquete p2;
            //ACT
            p1 = new Paquete("Casa", "2200");
            p2 = new Paquete("Trabajo", "2200");
            p1.Estado = Paquete.EEstado.Entregado;
            p2.Estado = Paquete.EEstado.Entregado;
            c1 = new Correo();
            try
            {
                c1 += p1;
                c1 += p2;
             //Assert
                Assert.Fail();
            }
            catch (Exception a)
            {

                Assert.IsInstanceOfType(a, typeof(TrackingIdRepetidoException));
            }
        }
        /// <summary>
        /// Prueba que la lista de Pquetes no sea nula.
        /// </summary>
        [TestMethod]
        public void TestMethod2()
        {
            //Arrange
            Correo c1;
            //Act
            c1= new Correo();
            //Assert
            Assert.IsNotNull(c1.Paquetes);

        }
    }
}
